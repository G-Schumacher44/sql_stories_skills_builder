# 📦 Sales & Returns Diagnostic – Project Bundle

This zip file includes all assets related to the diagnostic dashboard prepared for the VP of Sales. The project focuses on identifying return risks and optimizing revenue using a simulated ecommerce dataset.

---

## 📁 Contents

### Data Files (CSV)
- `orders.csv`
- `order_items.csv`
- `returns.csv`
- `return_items.csv`
- `customers.csv`
- `product_catalog.csv`

### Code
- `load_data.sql` — SQL script to create/load all tables

### Report
- `Sales_Diagnostic.pdf` — Final visual dashboard/report
- `Executive_Retail_Returns_Report.ipynb` — Jupyter notebook with analysis

---

## 🛠️ How to Use

- **SQL:** Load the `load_data.sql` file into your database (SQLite, Postgres, etc.)
- **Looker Studio:** Connect the CSVs to build a live dashboard.
- **Notebook:** Run the notebook in Jupyter or Colab to view preprocessing, analysis, and visualizations.

---

## 📬 Contact
Garrett Schumacher  
`me@garrettschumacher.com`