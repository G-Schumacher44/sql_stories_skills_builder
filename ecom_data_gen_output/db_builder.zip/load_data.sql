DROP TABLE IF EXISTS orders;
CREATE TABLE orders (
  order_id TEXT,
  total_items INTEGER,
  order_date DATE,
  customer_id TEXT,
  email TEXT,
  order_channel TEXT,
  is_expedited BOOLEAN,
  customer_tier TEXT,
  order_total REAL,
  payment_method TEXT,
  shipping_speed TEXT,
  shipping_cost REAL,
  agent_id TEXT,
  shipping_address TEXT,
  billing_address TEXT,
  clv_bucket TEXT
);

.mode csv
.import 'output/orders.csv' orders

DROP TABLE IF EXISTS order_items;
CREATE TABLE order_items (
  order_id TEXT,
  product_id INTEGER,
  product_name TEXT,
  category TEXT,
  quantity INTEGER,
  unit_price REAL
);

.mode csv
.import 'output/order_items.csv' order_items

DROP TABLE IF EXISTS returns;
CREATE TABLE returns (
  return_id TEXT,
  order_id TEXT,
  customer_id TEXT,
  email TEXT,
  return_date DATE,
  reason TEXT,
  return_type TEXT,
  refunded_amount REAL,
  return_channel TEXT,
  agent_id TEXT,
  refund_method TEXT
);

.mode csv
.import 'output/returns.csv' returns

DROP TABLE IF EXISTS return_items;
CREATE TABLE return_items (
  return_item_id INTEGER,
  return_id TEXT,
  order_id TEXT,
  product_id INTEGER,
  product_name TEXT,
  category TEXT,
  quantity_returned INTEGER,
  unit_price REAL,
  refunded_amount REAL
);

.mode csv
.import 'output/return_items.csv' return_items

DROP TABLE IF EXISTS customers;
CREATE TABLE customers (
  customer_id TEXT,
  age INTEGER,
  gender TEXT,
  loyalty_tier TEXT,
  signup_date TEXT,
  customer_status TEXT,
  email TEXT,
  email_verified BOOLEAN,
  marketing_opt_in BOOLEAN,
  loyalty_enrollment_date DATE,
  signup_channel TEXT,
  mailing_address TEXT,
  billing_address TEXT,
  clv_bucket TEXT,
  is_guest BOOLEAN
);

.mode csv
.import 'output/customers.csv' customers

DROP TABLE IF EXISTS product_catalog;
CREATE TABLE product_catalog (
  product_id INTEGER,
  product_name TEXT,
  category TEXT,
  unit_price REAL,
  inventory_quantity INTEGER
);

.mode csv
.import 'output/product_catalog.csv' product_catalog

